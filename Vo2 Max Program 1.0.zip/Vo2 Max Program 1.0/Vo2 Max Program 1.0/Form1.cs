﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// Estimating 6 hours of programming, however this could be more depending on how many issues crop up.
// I Went simpler without the radio buttons to try and figure out the setup. Took an unknown amount of time due to many short sessions.
namespace Vo2_Max_Program_1._0
//IF female
//100.5 - (bodyweight * .1636) - (1.438 * jog) - (.1928 * heart rate)
//IF Male
//108.844 - (.1636 * weight) - (1.438 * jog) - (.1928 * heart rate)
{
    public partial class Main : Form
    {
        
        public Main()
        {
            InitializeComponent();

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnFindMax_Click(object sender, EventArgs e)
        {
            int mage = Int32.Parse(txtMAge.Text);
            int mweight = Int32.Parse(txtMWeight.Text);
            int mjog = Int32.Parse(txtMJog.Text);
            int mheart = Int32.Parse(txtMHeart.Text);
            int mresult = 100.5 - (0.1636 * mweight) - (1.438 * mjog) - (.1928 * mheart);

            lblMResult - mresult.ToString();
        }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void radioButtonMale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonFemale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnFFindMax_Click(object sender, EventArgs e)
        {
            int fage = Int32.Parse(txtFAge.Text);
            int fweight = Int32.Parse(txtFWeight.Text);
            int fjog = Int32.Parse(txtFJog.Text);
            int fheart = Int32.Parse(txtFHeart.Text);
            int result = 100.5 - (0.1636 * fweight) - (1.438 * fjog) - (.1928 * fheart);

            lblFResult - result.ToString();
        }

        private void txtMAge_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
