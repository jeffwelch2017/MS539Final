﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vo2_Max_Program_1
{
    public class HealthCheck : MemberInfo 
    {
        #region Class Variables
        //Variables used to hold base formulas / Base class name
        private const double dFBaseValue = 100.5;
        private const double dMBaseValue = 108.884;
        private string sMyClassName;
        private string sMyBaseClass;

        #endregion

        #region Class Constructors
        public HealthCheck() : base()
        {
            sMyClassName = typeof(HealthCheck).Name;
        }
        public HealthCheck(MemberType.enumMemberType MbrType) : base(MbrType)
        {
            sMyClassName = typeof(HealthCheck).Name;
        }
        #endregion

        #region Class Methods
        public double GetStatus(Control frmCtrl)
        {
            
            double dBaseValue = 0.00;
            double dResult = 0.00;
            
            //Based on which radio is selected use the defined base value (See Constants)
            switch (base.MyMemberType)
            {
                case MemberType.enumMemberType.Male: {
                        //Calculated number for Male Members
                        dBaseValue = dMBaseValue;
                        break;
                    }
                case MemberType.enumMemberType.Female:
                    {
                        //Calculated number for Female Members
                        dBaseValue = dFBaseValue;
                        break;
                    }
                default:
                    dBaseValue = 104;
                    break;
            }

            //Get Results based on Gender
            dResult = dBaseValue - (0.1636 * base.MemberWeight) - (1.438 * base.MemberJogTime) - (.1928 * base.MemberHeartRate);

            //Send results to form Contnrol
            frmCtrl.Text = Math.Round(dResult, 1).ToString();
            frmCtrl.Refresh();

            return Math.Round(dResult,1);
            //Example Below short inline condition check for MemberType
            //dResult= (base.MyMemberType == enumMemberType.Female) ? dFBaseValue - (0.1636 * base.MemberWeight) - (1.438 * base.MemberJogTime) - (.1928 * base.MemberHeartRate) : dMBaseValue - (0.1636 * base.MemberWeight) - (1.438 * base.MemberJogTime) - (.1928 * base.MemberHeartRate);
            // (Condition) ? [True Value] : [False Value]  Structure -->  () ? :
        }

        #endregion

        #region Class Properties
        public override string MyClassName
        {
            get
            {
                sMyBaseClass = base.MyClassName;
                return string.Format("Top Class:{0}\n{1}", sMyClassName, sMyBaseClass);

            }
        }
        #endregion
    }
}
/*const VO2MaxRating = {
  52: 'Excellent',
  47: 'Good',
  42: 'Above Average',
  37: 'Average',
  30: 'Below Average',
  0: 'Poor',
}

const setRating = (rate, maxRatingObject) => {
  for (let vo2Rating in maxRatingObject) {
    if (rate >= parseInt(vo2Rating)) {
      return maxRatingObject[vo2Rating]
    }
  }
}
document.getElementById("outputVo2").textContent = vo2 + ' ml/kg/min (' + setRating(vo2, VO2MaxRating) + ")";
*/