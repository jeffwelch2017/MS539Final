﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Vo2_Max_Program_1
{
    public class Styler
    {
        #region Class Variables
        private Font fFont;
        private Color cBackColor;
        private Color cForeColor;
        private string sMyClassName = "";
        private string sStyleName = "";

        #endregion

        #region Class Constructors
        public Styler()
        {
            //Set just the class name
            sMyClassName = typeof(Styler).Name;
        }
        public Styler(Font myFont)
        {
            //Set Class Name and Font
            sMyClassName = typeof(Styler).Name;
            fFont = myFont;
        }

        public Styler(string StyleName)
        {
            //Set Class Name and Style name
            sMyClassName = typeof(Styler).Name;
            sStyleName = StyleName;
        }
        #endregion

        #region Class Properties
        public bool isUnderLined { get { return fFont.Underline; } }
        public bool isBolder { get { return fFont.Bold; } }
        public bool isItalic  { get { return fFont.Italic; } }
        public Color GetForeColor { get { return cForeColor; } }
        public Color GetBackColor { get { return cBackColor; } }
        public float MyFontSize { get { return fFont.Size; } }
        public Font MyFont { get { return fFont; } set { fFont = value; } }
        public string GetStyleName { get { return sStyleName; } }
        public virtual string MyClassName { get { return sMyClassName; } }
        #endregion

        #region Class Methods
        private Color HexColor(string ColorInHTMLHex)
        {
            //(Overloaded Method)
            //Takes in a Hexidecim HTML Color String Example: #FF8000 and converts to RGB decimal values
            int[] iRGB = new int[3];        //Hold RGB Values (3 member arrary)
            Color cColor = new Color();
            /*
             * FOR REFERENCE 
             * iRGB[0] = Red Decimal Value
             * iRGB[1] = Green Decimal Value
             * iRGB[2] = Blue Decimal Value
             */

            int iCnt = 0;                   //Used for RBG array value assignment
            string sHexStr = ColorInHTMLHex.Replace("#","");  //Remove Hash symbol to make it 6

            if (sHexStr.Length == 6)
            {
                //Make sures we have at least 6 values for a HTML Hex
                for (int i=0; i < sHexStr.Length;i+=2)
                {
                    //Get 2 characters at a time to parse Hex value and store value in array
                    iRGB[iCnt] = Convert.ToInt32(sHexStr.Substring(i, 2),16);
                    iCnt++;
                }
                //Assign RGB value from array and set color    
                cColor = Color.FromArgb(iRGB[0], iRGB[1], iRGB[2]);
            } else
            {
                //Not a valid HTML Color Code
                MessageBox.Show("Invalue Hex Value Parameter", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            return cColor;
        }

        public void SetForeColor(string ColorInHTMLHex)
        {
            //Take in HTMLHex Color Code and convert it to Color (ForeColor)
            cForeColor = HexColor(ColorInHTMLHex);
        }

        public void SetBackColor(string ColorInHTMLHex)
        {
            //Take in HTMLHex Color Code and convert it to Color (BackColor)
            cBackColor = HexColor(ColorInHTMLHex);
        }

        public void SetForeColor (Color myColor)
        {
            //straight Assignment (Overloaded Method)
            cForeColor = myColor;
        }

        public void SetBackColor(Color myColor)
        {
            //straight Assignment (Overloaded Method)
            cBackColor = myColor;
        }

        public void SetForeColor (int Red, int Green, int Blue)
        {
            //Set Color based on RGB Values (Overloaded Method)
            cForeColor = Color.FromArgb(Red, Green, Blue);
        }

        public void SetBackColor(int Red, int Green, int Blue)
        {
            //Set Color based on RGB Values (Overloaded Method)
            cBackColor = Color.FromArgb(Red, Green, Blue);
        }
        #endregion

    }
}
