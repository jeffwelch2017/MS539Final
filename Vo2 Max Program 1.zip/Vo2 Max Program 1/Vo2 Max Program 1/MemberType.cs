﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vo2_Max_Program_1
{
    public class MemberType
    {
        #region Class Variables
        //Public enumeration for Member type used to drive Main Logic
        public enum enumMemberType { Unspecified = 0, Male = 1, Female=2};
        private enumMemberType eMemberType;
        private string sMyClassName;        //Store class name for Polymorphic Methods
        #endregion

        #region Class Constructors
        public MemberType()
        {
            //Set Class name and MEmber Type
            sMyClassName = typeof(MemberType).Name;
            eMemberType = enumMemberType.Unspecified;
        }

        public MemberType(enumMemberType MbrType) 
        {
            //Set Class name and MEmber Type
            eMemberType = MbrType;
            sMyClassName = typeof(MemberType).Name;
        }
        #endregion

        #region Class Properties
        //Set or Get Local interanl values
        public enumMemberType MyMemberType { get { return eMemberType; } set { eMemberType = value; } }
        public virtual string MyClassName { get {return sMyClassName;} }
        #endregion



    }
}
