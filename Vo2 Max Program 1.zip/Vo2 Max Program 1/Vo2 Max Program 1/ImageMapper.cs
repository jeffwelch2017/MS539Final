﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Reflection;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Vo2_Max_Program_1
{
    public class ImageMapper
    {
        #region Class Variables
        private Point ptStart = new Point(0,0);
        private Point ptEnd = new Point(0, 0);
        private string sMyClassName="";
        private string sMapRegionName = "";
        private int iCategoryID=0;
        private double dValRangeLow = 0;
        private double dValRangeHigh = 0;
        private string sColorSection = "";
        private Panel pnlControl;
        
        #endregion

        #region Class Constructors
        public ImageMapper()
        {
            sMyClassName = typeof(ImageMapper).Name;
        }
        public ImageMapper(Control FormPanelControl)
        {
            sMyClassName = typeof(ImageMapper).Name;
            pnlControl = (Panel)FormPanelControl;
        }
        #endregion

        #region Class Properties
        public Panel MyPanelControl { get { return pnlControl; } set { pnlControl = value; } }
        public Point RegionBeginPoint { get { return ptStart; } set { ptStart = value;} }
        public Point RegionEndPoint { get { return ptEnd; } set { ptEnd = value; } }
        public string RegionName { get { return sMapRegionName; } set { sMapRegionName = value; } }
        public string MyClassName { get { return sMyClassName; } }
        public int GetCategoryID { get { return iCategoryID; } }
        public double GetRegionLowRange { get { return dValRangeLow; } }
        public double GetRegionHighRange { get { return dValRangeHigh; } }
        public string GetRegionColor { get { return sColorSection; } }

        #endregion

        #region Class Methods
        public void DefineRegion(Point RegionStartPoint, Point RegionEndPoint, string RegionName,int CategoryId, double ValueStartRange, double ValueEndRange,string ColorAsText, bool DrawRegionOnMap)
        {
            //Takes in a lots of information to define a range
            ptStart = RegionStartPoint;
            ptEnd = RegionEndPoint;
            sMapRegionName = RegionName;
            iCategoryID = CategoryId;
            dValRangeLow = ValueStartRange;
            dValRangeHigh = ValueEndRange;
            sColorSection = ColorAsText;

            //If Flag is set to true, this will show the region draw on the screen (Used for Debug to make sure the image is covered correctly)
            //Note this does not work on Form_load because panel control has not been rendered yet. If you want to see this work Create a button and call ShowMappingBounds
            if (DrawRegionOnMap) { ShowMappingBounds(Color.LightYellow);}

        }

        public void ShowMappingBounds(Color BoundingBoxColor)
        {
            //Graphics and Pen needed for paiting.
            Graphics g = pnlControl.CreateGraphics();
            Pen p = new Pen(BoundingBoxColor) {
                Width = 2 //Set Pen LineWidth
            };

            //DrawRectangle In Panel
            g.DrawRectangle(p, ptStart.X, ptStart.Y, ptEnd.X - ptStart.X, ptEnd.Y - ptStart.Y);
        }

        public void HideMappingBounds(Panel FrmPanel = null)
        {
            //Will clear internal Panel reference, unless external source is specified
            //Seeing it is assigned (in this case null) this means it is an optional parameter.
            if (FrmPanel != null)
            {
                //External Reference (FrmControl is a passed in Variable from external to the class)
                FrmPanel.Refresh();
                FrmPanel.Update();
            }
            else
            {
                //Internal Reference (pnlControl is a variable in this class)
                pnlControl.Refresh();
                pnlControl.Update();
            }
        }

        public void CircleRegion(Color CircleColor,int XOffset=0, int YOffset=0)
        {
            //Graphics and Pen needed for paiting.
            Graphics g = pnlControl.CreateGraphics();
            Pen p = new Pen(CircleColor)
            {
                Width = 2 //Set Pen LineWidth
            };

            //DrawRectangle In Panel
            g.DrawEllipse(p, ptStart.X-XOffset, ptStart.Y+YOffset, ptEnd.X - (ptStart.X-XOffset), ptEnd.Y - (ptStart.Y-YOffset));
        }
        #endregion



    }
}


