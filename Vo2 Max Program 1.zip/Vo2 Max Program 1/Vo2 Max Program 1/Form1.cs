﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
Estimating 6 hours of programming, however this could be more depending on how many issues crop up.
I Went simpler without the radio buttons to try and figure out the setup. Took an unknown amount of time due to many short sessions.

SOOOOOOO maybe NOT 6 hours, maybe days?....lol took forever to get a functional product going.

I reached out to Tom Wallace and he has assisted me over a 3 day period. We worked together on the coding and setup, Tom had a ton
of new items and ideas to work into the program to cover every aspect of the class requirements and then some.
We have left in notes, comments, old code and concepts, as well as some 'guideline' code I found that's actually in JavaScript but
I found to be useful as a logical guideline.

The imagemapper and it's usage of the styler class and data was pretty intensive and honestly above my capabilities. Tom took me through
process step by step and while I understand and could replicate the basics, I can't honestly say I'm 100% confident in being able to 
recreate it in it's entirety from scratch.

IF female
100.5 - (bodyweight * .1636) - (1.438 * jog) - (.1928 * heart rate)
IF Male
108.844 - (.1636 * weight) - (1.438 * jog) - (.1928 * heart rate)
*/
namespace Vo2_Max_Program_1
{
    public partial class Main : Form
    {
        #region ClassVariables
        //Variables for Holding type of Member (Male/Female), List of type <ImageMapper) and Dictionary Styles(Styler Class)
        private MemberType.enumMemberType eMyMember = MemberType.enumMemberType.Male;
        private List<ImageMapper> lImgMaps = new List<ImageMapper>();

        //String will be the Name it is lookup as such as Blue_, Yellow_, or Green_  and then the associated DL (Dark Left), LT (Light Top), or LB (Light Bottom)
        private Dictionary<string, Styler> dStyler = new Dictionary<string, Styler>();

        #endregion

        #region ClassConstructors
        public Main()
        {
            InitializeComponent();
        }

        #endregion

        #region ClassEvents
        private void rbFemale_CheckedChanged(object sender, EventArgs e)
        {
            //WHen the Readio Button is clicked set the internal Variable to eMyMember to a particular Value
            eMyMember = MemberType.enumMemberType.Female;
        }

        private void rbMale_CheckedChanged(object sender, EventArgs e)
        {
            //WHen the Readio Button is clicked set the internal Variable to eMyMember to a particular Value
            eMyMember = MemberType.enumMemberType.Male;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //Get me out of here
            Application.Exit();
        }

        private void btnMFindMax_Click(object sender, EventArgs e)
        {
            //Example of how to access by resource.
            //pnlVo2Men.BackgroundImage = Vo2_Max_Program_1.Properties.Resources.V02MaxMen;

            HealthCheck HC = new HealthCheck(eMyMember);

            int iAge, iWT, iHR, iJT;
            double dResults;
            bool bError = false;


            //Validation Check Age.
            if (int.TryParse(txtMAge.Text, out iAge) && !bError)
            {
                HC.MemberAge = iAge;
            }
            else if (!bError) {
                bError = true;
                MessageBox.Show("Invalid Age. Age must be a non-decimal and numeric number\n\nPlease try again.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                txtMAge.Text = "";
                txtMAge.Focus();
                txtMAge.Refresh();
            }

            //Validation Weight Time
            if (int.TryParse(txtMWeight.Text, out iWT) && !bError)
            {
                HC.MemberWeight = iWT;
            }
            else if (!bError)
            {
                bError = true;
                MessageBox.Show("Invalid Weight. Weight must be a non-decimal and numeric number\n\nPlease try again.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                txtMWeight.Text = "";
                txtMWeight.Focus();
                txtMWeight.Refresh();
            }

            //Validation Jog Time
            if (int.TryParse(txtMJog.Text, out iJT) && !bError)
            {
                HC.MemberJogTime = iJT;
            }
            else if (!bError)
            {
                bError = true;
                MessageBox.Show("Invalid Jog time (minutes). Jog must be a non-decimal and numeric number\n\nPlease try again.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                txtMJog.Text = "";
                txtMJog.Focus();
                txtMJog.Refresh();
            }

            //Validation Heart Time
            if (int.TryParse(txtMHeart.Text, out iHR) && !bError)
            {
                HC.MemberHeartRate = iHR;
            }
            else if (!bError)
            {
                bError = true;
                MessageBox.Show("Invalid Heart Rate. Rate must be a non-decimal and numeric number\n\nPlease try again.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                txtMHeart.Text = "";
                txtMHeart.Focus();
                txtMHeart.Refresh();
            }

            //Populate Score and return score value for later processing
            dResults = HC.GetStatus(lblInfoSNum);

            //Use Returned score to determine ImageMap to Circle and Color to use for Display of Code
            DisplayResults(dResults, iAge);

            //Build the Message for the Info Detail section and refresh all labels.
            lblInfoDtl.Text = string.Format("Gnd: {0}\nAge: {1}\nWgt: {2} lbs\nJT:  {3} (min)\nHR:  {4}", eMyMember.ToString(), iAge, iWT, iJT, iHR);
            lblInfoDtl.Refresh();
            lblInfoSH.Refresh();
            lblInfoSNum.Refresh();


            //This Property/Method Doesn't exist in the MemberInfo Class, but does in the Inherited class.
            //MyMemberType is a method from MemberType class

            //Exapmle 1
            //MessageBox.Show(HC.MyMemberType.ToString());

            //Example 2 (RIdes the whole way up from base to top super class)
            //MessageBox.Show(HC.MyClassName);


            //OLD CODE THAT WILL BE DELETED
            //int mage = Int32.Parse(txtMAge.Text);
            //int mweight = Int32.Parse(txtMWeight.Text);
            //int mjog = Int32.Parse(txtMJog.Text);
            //int mheart = Int32.Parse(txtMHeart.Text);
            //double mresult = 100.5 - (0.1636 * mweight) - (1.438 * mjog) - (.1928 * mheart);

            //HANDLED IN CLASS 
            //lblMResult.Text = Math.Round(mresult, 1).ToString();
            //lblMResult.Refresh();
        }


        private void Main_Load(object sender, EventArgs e)
        {
            //Set Defaults
            SetupStyles();
            SetInfoDefault();
            DefineImageRegions();
        }
        #endregion

        #region ClassMethods
    
        private void CleanUpImageArea()
        {
            //Clear Out Grid Prior to start
            ImageMapper IM = new ImageMapper();
            IM.HideMappingBounds(pnlVo2Female);
            IM.HideMappingBounds(pnlVo2Male);
            IM = null;
        }

        private void DisplayResults(double Results, int Age)
        {
            //Refresh Graphic Area (invalidates and refreshes)
            CleanUpImageArea();
            int iCatID=1;
            string sColorTheme="Blue";

            //Set Category (column) based on Age
            if (Age >= 20 && Age <= 39) { iCatID = 1; }
            else if (Age >= 40 && Age <= 49) { iCatID = 2; }
            else if (Age >= 50 && Age <= 59) { iCatID = 3; }
            else if (Age >= 60) { iCatID = 4; }

            //Search Library of ImageMapper to get Result Color Theme and Circle Matching MapLocation
            foreach (ImageMapper IM in lImgMaps)
            {
                if (IM.GetCategoryID == iCatID && IM.MyPanelControl.Name.Contains(eMyMember.ToString()))
                {
                    if ((Results >= IM.GetRegionLowRange && Results <= IM.GetRegionHighRange))
                    {
                        //Return Result Color and Circle Area.
                        sColorTheme = IM.GetRegionColor;
                        IM.CircleRegion(Color.Red, 1, 1);   //Offset to increase the Circle so it includes the whole value rather than cutting it off
                    }
                }
            }

            //Apply Style
            lblInfoDtl.BackColor = dStyler[string.Format("{0}_DL", sColorTheme)].GetBackColor;
            lblInfoDtl.ForeColor = dStyler[string.Format("{0}_DL", sColorTheme)].GetForeColor;
            lblInfoSH.BackColor = dStyler[string.Format("{0}_LT", sColorTheme)].GetBackColor;
            lblInfoSH.ForeColor = dStyler[string.Format("{0}_LT", sColorTheme)].GetForeColor;
            lblInfoSNum.BackColor = dStyler[string.Format("{0}_LB", sColorTheme)].GetBackColor;
            lblInfoSNum.ForeColor = dStyler[string.Format("{0}_LB", sColorTheme)].GetForeColor;
        }

        private void SetInfoDefault()
        {
            //Set Default Info
            lblInfoDtl.BackColor = dStyler["Default"].GetBackColor;
            lblInfoSH.BackColor = dStyler["Default"].GetBackColor;
            lblInfoSNum.BackColor = dStyler["Default"].GetBackColor;
            lblInfoDtl.BackColor = dStyler["Default"].GetForeColor;
            lblInfoSH.BackColor = dStyler["Default"].GetForeColor;
            lblInfoSNum.BackColor = dStyler["Default"].GetForeColor;
            lblInfoDtl.Refresh();
            lblInfoSH.Refresh();
            lblInfoSNum.Refresh();
        }

        private ImageMapper CreateQuickRegion(Panel PanelControl, Point PntStart, Point PntEnd, string RegionName, int CategoryID, double MinVal, double MaxVal, string StatusColorAsText)
        {
            //Method Creates Instance, Sets the information and returns the class
            //Designed to be a quick initializer that can be assigned
            ImageMapper IM = new ImageMapper(PanelControl);
            IM.DefineRegion(PntStart, PntEnd, RegionName, CategoryID, MinVal, MaxVal, StatusColorAsText, false);
            return IM;
        }

        private void CreateQuickStyle(string StyleName, string HTMLForeColor, string HTMLBackColor)
        {
            //Method Creates Instance, Sets the information and returns the class
            //Designed to be a quick initializer that can be assigned
            Styler S = new Styler(StyleName);
            S.SetBackColor(HTMLBackColor);
            S.SetForeColor(HTMLForeColor);
            dStyler[StyleName] = S;
            //return S;
        }

        private void CreateQuickStyle(string StyleName, int RedVal, int GreenVal, int BlueVal)
        {
            //Method Creates Instance, Sets the information and returns the class (Built for Default Style seeing)
            //Designed to be a quick initializer
            Styler S = new Styler(StyleName);
            S.SetBackColor(RedVal, GreenVal, BlueVal);
            S.SetForeColor(RedVal, GreenVal, BlueVal);
            dStyler[StyleName] = S;
            //return S;
        }

        private void SetupStyles()
        {
            //BUILD STYLES and Store them
            CreateQuickStyle("Default", 171, 171, 171);

            //Blue style (LT) (Score Header), (LB) (Score Num), (DL) Detail
            CreateQuickStyle("Blue_LT", "#3c5897", "#a0bcfb");
            CreateQuickStyle("Blue_LB", "#3c5897", "#a0bcfb");
            CreateQuickStyle("Blue_DL", "#c0ffff", "#3c5897");

            //Green style (LT) (Score Header), (LB) (Score Num), (DL) Detail
            CreateQuickStyle("Green_LT", "#2b701d", "#8fd481");
            CreateQuickStyle("Green_LB", "#2b701d", "#8fd481");
            CreateQuickStyle("Green_DL", "#c0ffc0", "#2b701d");

            //Yellow style (LT) (Score Header), (LB) (Score Num), (DL) Detail
            CreateQuickStyle("Yellow_LT", "#696900", "#f6cd64");
            CreateQuickStyle("Yellow_LB", "#696900", "#f6cd64");
            CreateQuickStyle("Yellow_DL", "#ffffc0", "#696900");
            //MessageBox.Show(dStyler.Count().ToString());
        }
        private void DefineImageRegions()
        {
            //Define Male Image Map Region (12 Boxes)
            //Creates a quick region by calling the method and creating an instance of the class. It then returns that instance and stores it in lImgMaps (List of type ImageMapper) for later reference
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(100, 50), new Point(180, 70), "> 50.4", 1, 50.4, 100, "Blue"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(100, 74), new Point(180, 94), "36.1-50.3", 1, 36.1, 50.3, "Green"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(100, 99), new Point(180, 119), "< 36", 1, -100,36, "Yellow"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(184, 50), new Point(264, 70), "> 47.3", 2, 47.3, 100, "Blue"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(184, 74), new Point(264, 94), "34.7-47.2", 2, 34.7, 47.2, "Green"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(184, 99), new Point(264, 119), "< 34.6", 2, -100,34.6, "Yellow"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(269, 50), new Point(349, 70), "> 42", 3, 42, 100, "Blue"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(269, 74), new Point(349, 94), "31.1-41.9", 3, 31.1, 41.9, "Green"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(269, 99), new Point(349, 119), "< 31", 3, -100, 31, "Yellow"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(354, 50), new Point(434, 70), "> 37.8", 4, 37.8, 100, "Blue"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(354, 74), new Point(434, 94), "26.1-37.7", 4, 26.1, 37.7, "Green"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Male, new Point(354, 99), new Point(434, 119), "< 26", 4, -100, 26, "Yellow"));

            //Define Female Image Map Region (12 Boxes)
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(100, 50), new Point(180, 70), "> 41", 1, 41, 100, "Blue"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(100, 74), new Point(180, 94), "28.8-40.9", 1, 28.8, 40.9, "Green"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(100, 99), new Point(180, 119), "< 28.7", 1, -100, 28.7, "Yellow"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(184, 50), new Point(264, 70), "> 37.8", 2, 37.8, 100, "Blue"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(184, 74), new Point(264, 94), "26.7-37.7", 2, 26.7, 37.7, "Green"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(184, 99), new Point(264, 119), "< 26.6", 2, -100, 26.6, "Yellow"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(269, 50), new Point(349, 70), "> 33.6", 3, 33.6, 100, "Blue"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(269, 74), new Point(349, 94), "23.6-33.5", 3, 23.6, 33.5, "Green"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(269, 99), new Point(349, 119), "< 23.5", 3, -100, 23.5, "Yellow"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(354, 50), new Point(434, 70), "> 30.1", 4, 30.1, 100, "Blue"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(354, 74), new Point(434, 94), "20.4-30", 4, 20.4, 30, "Green"));
            lImgMaps.Add(CreateQuickRegion(pnlVo2Female, new Point(354, 99), new Point(434, 119), "< 20.3", 4, -100, 20.3, "Yellow"));

            //Should be 24 Defined (Check is Below - For Debug Only)
            //MessageBox.Show(lImgMaps.Count.ToString());
        }
        #endregion
    }
}



