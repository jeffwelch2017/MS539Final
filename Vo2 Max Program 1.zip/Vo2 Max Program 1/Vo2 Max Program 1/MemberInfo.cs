﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Vo2_Max_Program_1
{
    public class MemberInfo : MemberType 
    {
        #region Class Variables
        //Variables
        private int iAge = 0;
        private int iWeight = 0;
        private int iJobMinutes = 0;
        private double dHeartRate = 0.00;
        private string sMyClassName;
        private string sMyBaseClass;

        #endregion

        #region Class Constructors
        public MemberInfo() : base()
        {
            sMyClassName = typeof(MemberInfo).Name;
        }

        public MemberInfo(MemberType.enumMemberType MbrType) : base(MbrType)
        {
            sMyClassName = typeof(MemberInfo).Name; 
        }
        #endregion


        #region Class Properties 
        //Properies for setting and getting info
        public int MemberAge { get { return iAge; } set { iAge = value; } }
        public int MemberWeight { get { return iWeight; } set { iWeight = value; } }
        public int MemberJogTime { get { return iJobMinutes; } set { iJobMinutes = value; } }
        public double MemberHeartRate { get { return dHeartRate; } set { dHeartRate = value; } }
        public override string MyClassName { 
            get {
                sMyBaseClass = base.MyClassName;
                //return sMyClassName; 
                return string.Format("Super Class:{0}\nBase Class :{1}", sMyClassName, sMyBaseClass);

           } 
        }
        #endregion


    }
}


